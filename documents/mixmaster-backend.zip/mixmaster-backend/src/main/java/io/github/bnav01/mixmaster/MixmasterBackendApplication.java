package io.github.bnav01.mixmaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MixmasterBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MixmasterBackendApplication.class, args);
	}

}
